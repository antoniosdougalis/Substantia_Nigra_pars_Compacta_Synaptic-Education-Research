#include <stdio.h>
#include "hocdec.h"
#define IMPORT extern __declspec(dllimport)
IMPORT int nrnmpi_myid, nrn_nobanner_;

extern void _A_reg();
extern void _AMPANetCon_reg();
extern void _GABANetCon_reg();
extern void _Gfluc_reg();
extern void _H_reg();
extern void _HHHmod_reg();
extern void _NadineCalChan2_reg();
extern void _NadineCalChan3l_reg();
extern void _NadineCalChan3s_reg();
extern void _cabalanmod_reg();
extern void _calcha_reg();
extern void _calchaT_reg();
extern void _capumpmod_reg();
extern void _kca_reg();
extern void _netstims_reg();
extern void _netstimss_reg();
extern void _nmda2_reg();

void modl_reg(){
	//nrn_mswindll_stdio(stdin, stdout, stderr);
    if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," A.mod");
fprintf(stderr," AMPANetCon.mod");
fprintf(stderr," GABANetCon.mod");
fprintf(stderr," Gfluc.mod");
fprintf(stderr," H.mod");
fprintf(stderr," HHHmod.mod");
fprintf(stderr," NadineCalChan2.mod");
fprintf(stderr," NadineCalChan3l.mod");
fprintf(stderr," NadineCalChan3s.mod");
fprintf(stderr," cabalanmod.mod");
fprintf(stderr," calcha.mod");
fprintf(stderr," calchaT.mod");
fprintf(stderr," capumpmod.mod");
fprintf(stderr," kca.mod");
fprintf(stderr," netstims.mod");
fprintf(stderr," netstimss.mod");
fprintf(stderr," nmda2.mod");
fprintf(stderr, "\n");
    }
_A_reg();
_AMPANetCon_reg();
_GABANetCon_reg();
_Gfluc_reg();
_H_reg();
_HHHmod_reg();
_NadineCalChan2_reg();
_NadineCalChan3l_reg();
_NadineCalChan3s_reg();
_cabalanmod_reg();
_calcha_reg();
_calchaT_reg();
_capumpmod_reg();
_kca_reg();
_netstims_reg();
_netstimss_reg();
_nmda2_reg();
}
